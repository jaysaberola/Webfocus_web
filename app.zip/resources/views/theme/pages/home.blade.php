@extends('theme.main')

@section('pagecss')
@endsection

@php
    $contents = $page->contents;

    $featuredArticles = Article::where('is_featured', 1)->where('status', 'Published')->take(env('FEATURED_NEWS_LIMIT'))->get();
    $featuredArticlesHTML = '';

    if ($featuredArticles->count()) {
   $featuredArticlesHTML .= '<div class="container topmargin-lg bottommargin-lg">
                                <div class="heading-block center">
                					<h3>Latest <span>News</span></h3>
                				</div>
        				        <div id="oc-posts" class="owl-carousel posts-carousel carousel-widget posts-md" data-pagi="false" data-items-xs="1" data-items-sm="2" data-items-md="3" data-items-lg="4">';
        foreach ($featuredArticles->chunk(env('FEATURED_NEWS_LIMIT')) as $index => $article) {
           

         
                foreach($article as $a){
                 $imageUrl = (empty($a->thumbnail_url)) ? asset('theme/images/misc/no-image.jpg') : $a->thumbnail_url;
                 $date = \Carbon\Carbon::parse($a->date_posted())->format('jS M Y');
                    $featuredArticlesHTML .= '<div class="oc-item">
                                                    <div class="entry topmargin-sm">
                            							<div class="entry-image">
                        						            <a href="#"><img src="'. $imageUrl .'" alt="'. $a->name .'"></a>
                        						        </div>
                            							<div class="entry-title title-xs nott">
                            								<h3><a href="'.$a->get_url().'">'. $a->name .'</a></h3>
                            							</div>
                            							<div class="entry-meta">
                            								<ul>
                            									<li><i class="icon-calendar3"></i>'. $date .'</li>
                            								</ul>
                            							</div>
                            							<div class="entry-content mt-3">
                            								<p>'. $a->teaser .'</p>
                            							</div>
                                                    </div>
                                                </div>';
                }
            $featuredArticlesHTML .= '</div><div class="text-center m-auto w-75">					
					<a href="https://cms4.webfocusprod.wsiph2.com/cms_standard/public/news" class="button button-border button-rounded ms-0 topmargin-sm button-small">Read More</a>
				</div></div>';
        }
    }



    $searchForm = '
    <form method="GET" action="'.route('search.result').'">
        <div class="input-group">
            <input type="text" name="searchtxt" class="form-control form-control-lg" placeholder="Search..." aria-label="Search" aria-describedby="button-addon2">
            <button class="btn btn-outline-primary btn-primary" type="submit" id="button-addon2"><i class="icon-search text-white"></i></button>
        </div>
    </form>';

    $time = '<span style="color:#000000;">'.\Carbon\Carbon::now()->format('l F, d Y').'</span>&nbsp;<span id="clock-wrapper" style="color:#000000;"></span>';

    $keywords   = ['{Featured Articles}', '{Search Form}', '{PST}'];
    $variables  = [$featuredArticlesHTML, $searchForm, $time];

    $contents = str_replace($keywords,$variables,$contents);


@endphp

@section('content')
    {!! $contents !!}
@endsection

@section('pagejs')
    <script>
        window.onload = function() {
            clock();  

            function clock() {
                var now = new Date();
                var TwentyFourHour = now.getHours();
                var hour = now.getHours();
                var min = now.getMinutes();
                var sec = now.getSeconds();
                var mid = 'PM';
            
                if (min < 10) {
                    min = "0" + min;
                }

                if (sec < 10) {
                    sec = "0" + sec;
                }

                if (hour > 12) {
                    hour = hour - 12;
                } 

                if(hour==0){ 
                    hour=12;
                }

                if(TwentyFourHour < 12) {
                   mid = 'AM';
                }  

                document.getElementById('clock-wrapper').innerHTML = hour+':'+min+':'+sec +' '+mid ;
                setTimeout(clock, 1000);
            }
        }
    </script>
@endsection