@extends('theme.main')

@section('pagecss')
    <link rel="stylesheet" href="{{ asset('theme/plugins/jssocials/jssocials.css') }}" />
    <link rel="stylesheet" href="{{ asset('theme/plugins/jssocials/jssocials-theme-flat.min.css') }}" />

    <style>
        {{ str_replace(array("'", "&#039;"), "", $news->styles ) }}
    </style>
@endsection

@section('content')
<div class="content-wrap">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 pe-lg-4">
                <div class="tablet-view">
                    <a href="javascript:void(0)" class="closebtn d-block d-lg-none" onclick="closeNav()">&times;</a>
                    <div class="card border-0">
                        <div class="border-0 mb-5">
						<h3 class="mb-3">Search</h3>
						<div class="search">
						     <form class="mb-0" id="frm_search" method="GET">
                                <div class="searchbar">
                                  <input type="text" class="form-control form-input form-search" placeholder="Search news" aria-label="Search news" aria-describedby="basic-addon2" name="searchtxt" id="searchtxt">
                                  <button class="form-submit-search" type="submit" name="submit">
										<i class="icon-line-search"></i>
									</button>
                                </div>
                            </form>
                    
						</div>
					</div>
					
                         <div class="border-0 mb-5">
							<h3 class="mb-3">News</h3>
							<div class="side-menu">
								{!!$dates!!}
							</div>
						</div>
                        <div class="border-0 mb-5">
							<h3 class="mb-3">Categories</h3>
							<div class="side-menu">
								{!!$categories!!}
							</div>
						</div>
                        
                    </div>
                </div>
            </div>
            
            <div class="col-lg-9">
                <div class="article-card">
					<div class="article-title">
						 <h2>{{$news->name}}</h2>
					</div>
					<div class="article-meta">
						<div class="entry-meta mb-3">
							<ul class="small">
								<li><i class="icon-calendar3"></i> {{ \Carbon\Carbon::parse($news->date)->format('jS M Y') }}</li>
								<li><i class="icon-user"></i> {{$news->user->name}}</li>
								<li><i class="icon-folder-open"></i> <a href="#">{{ $news->category->name }}</a></li>
							</ul>
						</div>
						<hr class="mb-4" />
					</div>
					<div class="article-image">
						<img class="mb-5 w-100" src="{{$news->thumbnail_url}}" alt="News 1">
					</div>
					<div class="news-desc mb-6">
						 {!! $news->contents !!}
					</div>
					
					<div class="news-share">
    					<h5>Share:</h5>
    					<div class="share_link"></div>
    				</div>
				</div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('pagejs')
    <script>
        $('#frm_search').on('submit', function(e) {
            e.preventDefault();
            console.log('sasasa');
            window.location.href = "{{route('news.front.index')}}?type=searchbox&criteria="+$('#searchtxt').val();
        });
    </script>
@endsection
