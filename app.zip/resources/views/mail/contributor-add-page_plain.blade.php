Dear {{ $senderName }},

I found this article interesting and I would like to share with you.
Please access the link below to view the relevant details of the article.

{{ route('pages.edit', $page->id) }}
