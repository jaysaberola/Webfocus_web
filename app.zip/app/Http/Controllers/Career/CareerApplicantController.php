<?php

namespace App\Http\Controllers\Career;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CareerApplicantController extends Controller
{
    //
}
